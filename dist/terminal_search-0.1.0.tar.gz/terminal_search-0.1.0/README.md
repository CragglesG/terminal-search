# Terminal Search

Terminal Search is a command-line application that allows users to search the internet using [Exa](https://exa.ai). It's built in Python using [Textual](https://textualize.io).
